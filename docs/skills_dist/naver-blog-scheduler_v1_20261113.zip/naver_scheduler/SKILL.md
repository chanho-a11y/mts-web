---
name: naver-blog-scheduler
description: MTSPACE COFFEE 네이버 블로그(mtspace-coffee)에 원고와 이미지를 넣어 예약 발행을 일괄로 걸 때 사용. 원고 검수, 이미지 업로드, SmartEditor 자동 입력, 예약 검증까지 포함.
---

# 네이버 블로그 예약 발행 스킬

네이버는 글쓰기 API가 없다. 대표 Mac의 Chrome(로그인된 세션)을 Control_Chrome 도구로 조작해 SmartEditor ONE에 직접 입력하고, 발행 설정에서 "예약"으로 등록한다. 예약은 네이버 서버에 저장되므로 등록 후에는 Mac이 꺼져 있어도 발행된다. 예약 가능 범위는 약 1년.

## 0. 전제

- Chrome에 mtspace-coffee 아이디로 로그인되어 있을 것. 아니면 대표에게 로그인을 요청하고 멈춘다(비밀번호 입력 금지).
- Claude 내장 브라우저는 네이버 도메인이 막혀 있고, 컴퓨터 화면 조작은 브라우저가 읽기 전용이다. 반드시 Control_Chrome(execute_javascript)을 쓴다.
- Desktop Commander 쉘에서 osascript로 Chrome을 직접 제어하는 것은 권한이 없다(-1743). 쓰지 않는다.
- 도구 폴더: `/Users/chanhohong/MTS/MTSPACE COFFEE/_tools/naver_scheduler/`
  - `upload_imgs.sh <주차폴더> <키>`: 01~04 PNG를 Supabase `product-assets/naver-blog/<키>/0N.png`로 업로드
  - `upload_cfg.sh <json> <이름>`: 예약 설정 JSON 업로드(브라우저가 fetch로 읽음)
  - `fetch_src.sh <slug...>`: 자사몰 원문 텍스트 저장(중복 검사용)
  - `nbs_post.js`: SmartEditor 입력 루틴 원본
  - `gen_cfg.py`: 원고.txt 폴더들로 예약 설정 JSON 생성
- 업로드 스크립트는 `new-website/.env.local`의 service role 키를 읽는다. 키는 절대 출력하지 않는다.

## 1. 원고 규칙 (예약 전 전수 검사)

- 원고 폴더 형식: `원고.txt`(제목, 본문, 태그, 발행 설정 섹션) + `01_대표이미지.png`(1080²) + `02~04_*.png`(1080×1350). 본문에 `[이미지 2]`~`[이미지 4]` 표시.
- 금지: 긴 줄표, 가운뎃점, 지역명(가평, 청평 등), 로스팅/출고 요일과 일정, 제품 용량(125g, 1kg 등, 레시피 그램 수치는 허용), 절대 표현(최고, 유일, 완벽), N:W, split, QC 같은 B2B 약어, 아아 블렌드(단종), 가공법 태그.
- 본문 1,500자 이상(공백 포함), 태그 5개, 링크 3개 이하(검증된 mtspace.coffee 경로만).
- 자사몰 글을 옮길 때는 전면 재작성. 원문과 25자 연속 일치 0건(공백 무시). 사실(가격, 노트, 레시피, 산지, 비율)은 그대로.
- 가격은 예약 직전 자사몰 DB(product_variant.base_price)와 대조.
- 이미지 렌더 소스: 각 분기 폴더의 `_소스_재생성용/`(Playwright + HTML 템플릿, 폰트 base64 내장).

## 2. 절차

1. 원고 검수(위 규칙)와 대표 확인이 필요한 항목을 정리한다.
2. 이미지 업로드: `upload_imgs.sh` (키 = 주차 코드, 예 W05, R01).
3. 예약 설정 생성: `gen_cfg.py`로 `[{key,title,blocks,tags,category,date,hour,minute,open,confirm}]` JSON을 만들고 `upload_cfg.sh`로 올린다. 발행 시각 기본값은 월요일 19:10.
4. 브라우저 준비(Control_Chrome, blog.naver.com 탭에서):
   - `localStorage.nbs_routine`에 `nbs_post.js` 본문 저장(이미 있으면 생략).
   - 설정 JSON을 fetch해 `localStorage['nbs_cfg_'+key]`로 저장.
5. 글마다:
   - 탭을 `https://blog.naver.com/mtspace-coffee/postwrite`로 이동.
   - `window.__NBS_CFG=JSON.parse(localStorage.getItem('nbs_cfg_KEY')); (new Function(localStorage.getItem('nbs_routine')))()`
   - `window.__nbs`를 폴링. stage가 `ready`를 지나 `confirmed`가 되고, 탭 주소가 `PostList...logNo=...&isAfterWrite=true`로 바뀌면 성공. logNo를 기록한다.
   - 처음 쓰는 원고 묶음은 먼저 `confirm:false`로 1편 돌려 `__nbs.summary`(제목, 이미지 수, 날짜, 시각, 카테고리)를 확인한 뒤 확정한다.
6. 검증: RSS(`https://rss.blog.naver.com/mtspace-coffee.xml`)에 예약 글이 없어야 한다(예약은 발행 시각 전까지 비공개). 첫 예약일 당일 발행을 확인한다.
7. 결과를 원고 폴더의 `예약기록.md`와 의사결정 로그에 남긴다.

## 3. 루틴이 처리하는 것과 함정

- 제목과 본문은 숨은 contenteditable에 ClipboardEvent paste로 넣는다. 붙여넣기 전 커서 위치를 마우스 이벤트로 잡아야 한다. 마지막 문단은 오른쪽 아래 끝을 눌러야 글 중간에 끼어들지 않는다.
- 에디터 텍스트는 공백이 nbsp로 바뀌므로 비교 전에 정규화한다.
- 이미지는 Supabase 공개 URL을 fetch해 File로 붙여넣으면 네이버 서버(pstatic)로 업로드된다.
- 발행 레이어: 카테고리 라디오, 공개 범위, 태그(입력 후 Enter), 예약 라디오, jQuery 달력(월 이동 후 날짜 클릭), 시와 분 select.
- 붙여넣은 URL은 하이퍼링크가 되지 않는다(텍스트로 남음).
- 이전 작성 내용 복원 팝업은 "취소"로 닫는다. 에디터가 비어 있지 않으면 루틴이 멈춘다.
- 네이버 경고창(alert)이 뜨면 Chrome 스크립트가 전부 멈춘다. 대표에게 확인 클릭을 요청한다.
- 발행 버튼 직후 "로그인이 해제" 경고가 뜨면 저장되지 않은 것이다. 재로그인 후 같은 글을 다시 돌린다(글쓰기 화면에 복원 팝업이 남아 있으면 미발행 신호).
- 파일, 글, 예약은 삭제하지 않는다. 취소나 삭제는 대표가 네이버에서 직접 한다.
