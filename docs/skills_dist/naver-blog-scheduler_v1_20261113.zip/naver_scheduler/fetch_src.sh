#!/bin/zsh
# 자사몰 블로그 원문(body_html)을 받아 태그를 벗긴 텍스트로 저장한다. 사용: fetch_src.sh <slug> [<slug>...]
ROOT="/Users/chanhohong/MTS/MTSPACE COFFEE"
KEY=$(sed -n 's/^SUPABASE_SERVICE_ROLE_KEY=//p' "$ROOT/new-website/.env.local" | head -1 | tr -d "\"' \r")
OUT="$ROOT/_tools/naver_scheduler/src"; mkdir -p "$OUT"
for s in "$@"; do
  enc=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$s")
  curl -s -H "apikey: $KEY" -H "Authorization: Bearer $KEY" \
    "https://apiskyivlvebpvvxfejq.supabase.co/rest/v1/content_post?slug=eq.$enc&select=title,excerpt,body_html" \
  | python3 -c "
import json,sys,re,html
d=json.load(sys.stdin)[0]
t=re.sub(r'<(br|/p|/h[1-6]|/li|/tr|/td|/th)[^>]*>','\n',d['body_html']); t=html.unescape(re.sub(r'<[^>]+>','',t))
sys.stdout.write(d['title']+'\n'+(d.get('excerpt') or '')+'\n'+t)" > "$OUT/$s.txt"
  echo "$(wc -c < "$OUT/$s.txt") $s"
done
