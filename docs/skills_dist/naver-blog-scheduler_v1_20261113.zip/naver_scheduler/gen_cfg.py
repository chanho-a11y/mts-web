# 원고.txt 들을 읽어 예약 설정(cfg) JSON 배열을 만든다. 사용: gen_cfg.py <원고루트> <키접두 매핑 json> > cfgs.json
import json, re, sys, os
BASE = "https://apiskyivlvebpvvxfejq.supabase.co/storage/v1/object/public/product-assets/naver-blog"
def parse(path):
    t = open(path, encoding="utf-8").read()
    sec = dict(re.findall(r"=== (.+?) ===\n(.*?)(?=\n=== |\Z)", t, re.S))
    get = lambda k: next(v for kk, v in sec.items() if kk.startswith(k)).strip()
    return get("제목"), get("본문"), get("태그").replace("#", "").split(), get("발행 설정")
def cfg(folder_path, key, date, hour="19", minute="10"):
    title, body, tags, meta = parse(os.path.join(folder_path, "원고.txt"))
    cat = re.search(r"카테고리: (.+)", meta).group(1).strip()
    parts = re.split(r"\n*\[이미지 (\d)\]\n*", body)
    blocks = [{"t": "img", "url": f"{BASE}/{key}/01.png"}]
    blocks.append({"t": "text", "v": parts[0].strip()})
    for i in range(1, len(parts), 2):
        blocks.append({"t": "img", "url": f"{BASE}/{key}/{int(parts[i]):02d}.png"})
        blocks.append({"t": "text", "v": parts[i + 1].strip()})
    return {"key": key, "title": title, "blocks": blocks, "tags": tags, "category": cat, "date": date, "hour": hour, "minute": minute, "open": "public", "confirm": True}
if __name__ == "__main__":
    root = sys.argv[1]; plan = json.load(open(sys.argv[2]))
    out = [cfg(os.path.join(root, p["folder"]), p["key"], p["date"]) for p in plan]
    json.dump(out, sys.stdout, ensure_ascii=False)
