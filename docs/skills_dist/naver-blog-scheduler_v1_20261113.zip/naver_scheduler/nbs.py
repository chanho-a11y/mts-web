#!/usr/bin/env python3
"""네이버 블로그 예약 발행 헬퍼: 로컬 파일(텍스트, 이미지)을 Chrome 탭의 JS로 전달한다.
사용: nbs.py js <file.js>            -> 탭에서 JS 실행, 결과 출력
      nbs.py img <png> [<png>...]    -> window.__nbsImgs 배열에 File 로 적재 (base64 분할 전송)
      nbs.py text <txt> <varname>    -> window[varname] 에 텍스트 적재
탭 선택: URL 에 NBS_TAB_MATCH (기본 'mtspace-coffee/postwrite') 를 포함하는 첫 탭
"""
import base64, os, subprocess, sys, tempfile, json

MATCH = os.environ.get("NBS_TAB_MATCH", "mtspace-coffee/postwrite")
CHUNK = 200_000

APPLESCRIPT = r'''
on run argv
  set jsPath to item 1 of argv
  set matchStr to item 2 of argv
  set js to read (POSIX file jsPath) as «class utf8»
  tell application "Google Chrome"
    repeat with w in windows
      repeat with t in tabs of w
        if (URL of t) contains matchStr then
          return (execute t javascript js)
        end if
      end repeat
    end repeat
  end tell
  return "NBS_ERR_NO_TAB"
end run
'''

def run_js(code: str) -> str:
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(code)
        p = f.name
    with tempfile.NamedTemporaryFile("w", suffix=".applescript", delete=False) as s:
        s.write(APPLESCRIPT)
        sp = s.name
    r = subprocess.run(["osascript", sp, p, MATCH], capture_output=True, text=True, timeout=120)
    out = (r.stdout or "").strip()
    if r.returncode != 0:
        raise SystemExit("osascript 실패: " + r.stderr.strip())
    if out == "NBS_ERR_NO_TAB":
        raise SystemExit("대상 탭 없음: " + MATCH)
    return out

def load_imgs(paths):
    run_js("window.__nbsImgs=[];'ok'")
    for i, path in enumerate(paths):
        b64 = base64.b64encode(open(path, "rb").read()).decode()
        run_js("window.__nbsB64='';'ok'")
        for k in range(0, len(b64), CHUNK):
            run_js("window.__nbsB64+=" + json.dumps(b64[k:k+CHUNK]) + ";'ok'")
        name = os.path.basename(path)
        mime = "image/png" if name.lower().endswith(".png") else "image/jpeg"
        res = run_js(
            "(()=>{const s=atob(window.__nbsB64);const a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);"
            f"window.__nbsImgs.push(new File([a],{json.dumps('img%02d_' % i + name.encode('ascii','ignore').decode() or 'img.png')},{{type:{json.dumps(mime)}}}));"
            "window.__nbsB64='';return String(a.length)})()")
        if res != str(os.path.getsize(path)):
            raise SystemExit(f"바이트 불일치 {path}: {res} != {os.path.getsize(path)}")
        print(f"img {i} ok {res}B {name}")

def main():
    cmd = sys.argv[1]
    if cmd == "js":
        print(run_js(open(sys.argv[2], encoding="utf-8").read()))
    elif cmd == "img":
        load_imgs(sys.argv[2:])
    elif cmd == "text":
        t = open(sys.argv[2], encoding="utf-8").read()
        print(run_js(f"window[{json.dumps(sys.argv[3])}]={json.dumps(t)};String(window[{json.dumps(sys.argv[3])}].length)"))
    else:
        raise SystemExit("unknown cmd")

if __name__ == "__main__":
    main()
