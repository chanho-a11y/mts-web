// 네이버 블로그 SmartEditor ONE 예약 발행 루틴. Control_Chrome execute_javascript 로 글쓰기 탭에서 실행.
// 사용: 맨 아래 window.__NBS_CFG 를 채워 이 파일 전체를 실행하면 비동기로 진행되고,
//       진행 상태는 window.__nbs (stage, log, error, done) 로 폴링한다.
// cfg = {title, blocks:[{t:'text',v:'...'}|{t:'img',url:'https://...'}], tags:[...], category:'...',
//        date:'YYYY-MM-DD', hour:'19', minute:'10', open:'public'|'private', confirm:true|false}
(() => {
  const cfg = window.__NBS_CFG;
  const S = window.__nbs = { stage: 'start', log: [], error: null, done: false };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const log = m => { S.log.push(m); S.stage = m; };
  const hidden = () => [...document.querySelectorAll('[contenteditable]')].find(e => !e.offsetParent);
  const fire = (el, xFrac, yEnd) => {
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width * xFrac, clientY: yEnd ? r.bottom - 3 : r.top + r.height / 2, button: 0 };
    ['mousedown', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, o)));
  };
  const paste = (dt) => { const h = hidden(); h.innerHTML = ''; h.focus(); h.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); };
  const caretEnd = () => {
    const comps = [...document.querySelectorAll('.se-components-wrap .se-component')];
    const last = comps[comps.length - 1];
    let ps = last ? [...last.querySelectorAll('.se-text-paragraph')] : [];
    if (!ps.length) throw new Error('마지막 컴포넌트에 텍스트 문단 없음: ' + (last && last.className));
    const p = ps[ps.length - 1];
    p.scrollIntoView({ block: 'center' });
    fire(p, 0.999, true);
  };
  const waitFor = async (fn, ms, what) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const v = fn(); if (v) return v; await sleep(250); } throw new Error('시간 초과: ' + what); };
  const html = t => t.split('\n').map(l => '<p>' + (l ? l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/(https:\/\/[^\s<]+)/g, '<a href="$1">$1</a>') : '<br>') + '</p>').join('');

  (async () => {
    try {
      if (!document.querySelector('.se-documentTitle')) throw new Error('에디터 없음');
      // 이전 글 이어쓰기 팝업 닫기(취소 = 새 글)
      const resume = [...document.querySelectorAll('button')].find(b => b.offsetParent && /취소/.test(b.innerText) && b.closest('[class*=popup]'));
      if (resume) { resume.click(); await sleep(800); }
      if (document.querySelectorAll('.se-component.se-image').length || document.querySelector('.se-documentTitle').innerText.trim() !== '제목')
        throw new Error('에디터가 비어 있지 않음. 새 글쓰기 화면에서 다시 시작');
      // 1. 제목
      fire(document.querySelector('.se-documentTitle .se-text-paragraph'), 0.1);
      let dt = new DataTransfer(); dt.setData('text/plain', cfg.title); paste(dt);
      await waitFor(() => norm(document.querySelector('.se-documentTitle').innerText) === norm(cfg.title), 5000, '제목 입력');
      log('title');
      // 2. 본문 블록
      let first = true;
      for (const [i, b] of cfg.blocks.entries()) {
        if (first) { fire(document.querySelector('.se-component.se-text .se-text-paragraph'), 0.05); first = false; } else caretEnd();
        await sleep(200);
        if (b.t === 'text') {
          dt = new DataTransfer(); dt.setData('text/plain', b.v); dt.setData('text/html', html(b.v)); paste(dt);
          const probe = b.v.split('\n')[0].slice(0, 12);
          await waitFor(() => [...document.querySelectorAll('.se-component.se-text')].some(c => norm(c.innerText).includes(norm(probe))), 6000, '텍스트 입력 ' + i); await sleep(300);
        } else {
          const before = document.querySelectorAll('.se-component.se-image').length;
          const blob = await (await fetch(b.url)).blob();
          if (!blob.size || !/image/.test(blob.type)) throw new Error('이미지 다운로드 실패 ' + b.url);
          dt = new DataTransfer(); dt.items.add(new File([blob], 'img' + i + '.png', { type: blob.type })); paste(dt);
          await waitFor(() => { const im = document.querySelectorAll('.se-component.se-image img'); return im.length > before && /pstatic/.test(im[im.length - 1].src); }, 30000, '이미지 업로드 ' + i);
          await sleep(600);
          // 이미지 뒤에 텍스트 컴포넌트가 없으면 엔터로 만든다
          const comps = [...document.querySelectorAll('.se-components-wrap .se-component')];
          if (!comps[comps.length - 1].classList.contains('se-text') && i < cfg.blocks.length - 1) {
            const img = comps[comps.length - 1]; fire(img, 0.5); await sleep(200);
            const h = hidden(); h.focus(); h.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            await sleep(400);
          }
        }
        log('block ' + i + ' ' + b.t);
      }
      if (cfg.stopAfterBody) { S.done = true; log('body-only'); return; }
      // 3. 발행 설정 레이어
      const topBtn = [...document.querySelectorAll('button')].find(b => b.offsetParent && b.innerText.trim() === '발행' && !b.closest('[class*=layer_popup]'));
      topBtn.click();
      const L = await waitFor(() => document.querySelector('[class*=layer_popup][class*=is_show]'), 8000, '발행 레이어');
      log('layer');
      // 카테고리
      L.querySelector('button[class*=selectbox_button]').click(); await sleep(400);
      const lab = [...L.querySelectorAll('[class*=option_list_layer] label')].find(l => l.innerText.trim() === cfg.category);
      if (!lab) throw new Error('카테고리 없음: ' + cfg.category);
      lab.click(); await sleep(300);
      if (L.querySelector('button[class*=selectbox_button]').innerText.trim() !== cfg.category) throw new Error('카테고리 미적용');
      // 공개 범위
      document.querySelector(cfg.open === 'private' ? 'label[for=open_private]' : 'label[for=open_public]').click();
      // 태그
      const ti = document.getElementById('tag-input'); const setv = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
      for (const t of cfg.tags) {
        ti.focus(); setv.call(ti, t); ti.dispatchEvent(new Event('input', { bubbles: true }));
        ['keydown', 'keyup'].forEach(k => ti.dispatchEvent(new KeyboardEvent(k, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })));
        await sleep(250);
      }
      log('cat+tags');
      // 예약
      document.querySelector('label[for=radio_time2]').click(); await sleep(400);
      const [Y, M, D] = cfg.date.split('-').map(Number);
      L.querySelector('input[class*=input_date]').click(); await sleep(400);
      for (let k = 0; k < 14; k++) {
        const C = document.querySelector('.ui-datepicker');
        const tt = C.querySelector('.ui-datepicker-title').innerText.replace(/\s/g, '');
        if (tt === `${Y}년${M}월`) break;
        C.querySelector('.ui-datepicker-next').click(); await sleep(300);
      }
      const C = document.querySelector('.ui-datepicker');
      if (C.querySelector('.ui-datepicker-title').innerText.replace(/\s/g, '') !== `${Y}년${M}월`) throw new Error('달력 월 이동 실패');
      const day = [...C.querySelectorAll('td:not(.ui-state-disabled) button')].find(x => x.innerText.trim() === String(D));
      if (!day) throw new Error('선택 불가 날짜 ' + cfg.date);
      day.click(); await sleep(300);
      const sel = (q, v) => { const s = L.querySelector(q); Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set.call(s, v); s.dispatchEvent(new Event('change', { bubbles: true })); return s.value; };
      sel('select[class*=hour_option]', cfg.hour); sel('select[class*=minute_option]', cfg.minute); await sleep(300);
      const want = `${Y}. ${String(M).padStart(2, '0')}. ${String(D).padStart(2, '0')}`;
      const got = { date: L.querySelector('input[class*=input_date]').value, h: L.querySelector('select[class*=hour_option]').value, m: L.querySelector('select[class*=minute_option]').value, pre: document.getElementById('radio_time2').checked };
      if (got.date !== want || got.h !== cfg.hour || got.m !== cfg.minute || !got.pre) throw new Error('예약 값 불일치 ' + JSON.stringify(got));
      S.summary = { title: document.querySelector('.se-documentTitle').innerText.trim(), images: document.querySelectorAll('.se-component.se-image').length, tags: [...L.querySelectorAll('[class*=tag_item], [class*=tag] span')].map(e => e.innerText.trim()).filter(t => t.startsWith('#')), ...got, category: L.querySelector('button[class*=selectbox_button]').innerText.trim() };
      log('ready');
      if (cfg.confirm) { L.querySelector('button[class*=confirm_btn]').click(); log('confirmed'); }
      S.done = true;
    } catch (e) { S.error = String(e && e.message || e); }
  })();
  return 'started';
})();
