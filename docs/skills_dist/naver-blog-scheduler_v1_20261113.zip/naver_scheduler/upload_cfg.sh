#!/bin/zsh
# 예약 설정 JSON 을 Supabase product-assets/naver-blog/cfg/<이름>.json 으로 올린다(버킷이 이미지 MIME 만 허용해 image/png 헤더로 저장).
# 사용: upload_cfg.sh <json파일> <이름>
ROOT="/Users/chanhohong/MTS/MTSPACE COFFEE"
KEY=$(sed -n 's/^SUPABASE_SERVICE_ROLE_KEY=//p' "$ROOT/new-website/.env.local" | head -1 | tr -d "\"' \r")
curl -s -o /tmp/nbs_cfg_up.txt -w "%{http_code} " -X POST -H "Authorization: Bearer $KEY" -H "apikey: $KEY" \
  -H "Content-Type: image/png" -H "x-upsert: true" --data-binary @"$1" \
  "https://apiskyivlvebpvvxfejq.supabase.co/storage/v1/object/product-assets/naver-blog/cfg/$2.json"
echo "https://apiskyivlvebpvvxfejq.supabase.co/storage/v1/object/public/product-assets/naver-blog/cfg/$2.json"
cat /tmp/nbs_cfg_up.txt; echo
