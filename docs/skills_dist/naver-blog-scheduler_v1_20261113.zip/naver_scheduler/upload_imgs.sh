#!/bin/zsh
# 사용: upload_imgs.sh <주차폴더> <키(예: W05)>
# 폴더의 01~04 PNG 를 Supabase product-assets/naver-blog/<키>/0N.png 로 올리고 공개 URL 을 출력한다.
set -e
ROOT="/Users/chanhohong/MTS/MTSPACE COFFEE"
ENV="$ROOT/new-website/.env.local"
KEY=$(sed -n 's/^SUPABASE_SERVICE_ROLE_KEY=//p' "$ENV" | head -1 | tr -d "\"' \r")
BASE="https://apiskyivlvebpvvxfejq.supabase.co"
DIR="$1"; K="$2"
for f in "$DIR"/0[1-4]_*.png; do
  n=$(basename "$f" | cut -c1-2)
  code=$(curl -s -o /tmp/nbs_up.txt -w "%{http_code}" -X POST \
    -H "Authorization: Bearer $KEY" -H "apikey: $KEY" -H "Content-Type: image/png" -H "x-upsert: true" \
    --data-binary @"$f" "$BASE/storage/v1/object/product-assets/naver-blog/$K/$n.png")
  echo "$code $BASE/storage/v1/object/public/product-assets/naver-blog/$K/$n.png"
done
